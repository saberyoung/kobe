kobe.KBtelescope.tilings.read\_pointings
========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.read_pointings