kobe.KBpointings.galaxies.readp
===============================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.readp