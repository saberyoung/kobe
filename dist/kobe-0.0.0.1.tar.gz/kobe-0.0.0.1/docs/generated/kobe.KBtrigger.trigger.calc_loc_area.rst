kobe.KBtrigger.trigger.calc\_loc\_area
======================================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.calc_loc_area