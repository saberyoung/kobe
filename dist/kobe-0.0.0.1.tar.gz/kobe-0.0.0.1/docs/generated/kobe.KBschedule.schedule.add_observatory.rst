kobe.KBschedule.schedule.add\_observatory
=========================================

.. currentmodule:: kobe.KBschedule

.. automethod:: schedule.add_observatory