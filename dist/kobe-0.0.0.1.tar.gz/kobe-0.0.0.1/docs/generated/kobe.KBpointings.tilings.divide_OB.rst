kobe.KBpointings.tilings.divide\_OB
===================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.divide_OB