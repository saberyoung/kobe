kobe.KBcirculate.utils
======================

.. currentmodule:: kobe.KBcirculate

.. autoclass:: utils

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~utils.__init__
      ~utils.ckdir
      ~utils.ckpython
      ~utils.common_ele
      ~utils.flatten
      ~utils.gcn_server
      ~utils.getkeys
      ~utils.ipix_in_box
      ~utils.is_seq
      ~utils.is_seq_of_seq
      ~utils.readlist
      ~utils.setkeys
      ~utils.vertices
      ~utils.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~utils.defkwargs
      ~utils.exkwargs
      ~utils.version
   
   