kobe.KBtrigger.trigger.fits
===========================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.fits