kobe.KBpointings.tilings.removep\_file
======================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.removep_file