kobe.KBpointings.galaxies.removep\_file
=======================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.removep_file