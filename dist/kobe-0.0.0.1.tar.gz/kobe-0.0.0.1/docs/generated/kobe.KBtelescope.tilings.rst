kobe.KBtelescope.tilings
========================

.. currentmodule:: kobe.KBtelescope

.. autoclass:: tilings

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~tilings.__init__
      ~tilings.ckdir
      ~tilings.ckpython
      ~tilings.closefig
      ~tilings.common_ele
      ~tilings.compute_contours
      ~tilings.cumshow
      ~tilings.distview
      ~tilings.divide_OB
      ~tilings.divide_OB_one
      ~tilings.flatten
      ~tilings.galaxyshow
      ~tilings.galaxyshow_all
      ~tilings.galaxyshow_obs
      ~tilings.galaxyshow_tel
      ~tilings.gcn_server
      ~tilings.generate_pointings
      ~tilings.getkeys
      ~tilings.healpyshow
      ~tilings.ipix_in_box
      ~tilings.is_seq
      ~tilings.is_seq_of_seq
      ~tilings.lumsview
      ~tilings.notes
      ~tilings.plot_coord
      ~tilings.plot_lines
      ~tilings.plot_points
      ~tilings.plot_sky
      ~tilings.projplot
      ~tilings.read_pointings
      ~tilings.read_slackid
      ~tilings.readlist
      ~tilings.remove_pointings_coo
      ~tilings.remove_pointings_file
      ~tilings.routeview
      ~tilings.save_pointings
      ~tilings.savefig
      ~tilings.send_email
      ~tilings.send_slack
      ~tilings.send_sms
      ~tilings.setkeys
      ~tilings.tilingshow
      ~tilings.tilingshow_all
      ~tilings.tilingshow_obs
      ~tilings.tilingshow_tel
      ~tilings.triggershow
      ~tilings.vertices
      ~tilings.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~tilings.attachments
      ~tilings.data
      ~tilings.defkwargs
      ~tilings.exkwargs
      ~tilings.images
      ~tilings.texts
      ~tilings.version
   
   