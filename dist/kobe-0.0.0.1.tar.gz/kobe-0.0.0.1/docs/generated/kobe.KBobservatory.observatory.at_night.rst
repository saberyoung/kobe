kobe.KBobservatory.observatory.at\_night
========================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.at_night