kobe.KBplotter.vcandidates
==========================

.. currentmodule:: kobe.KBplotter

.. autoclass:: vcandidates

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~vcandidates.__init__
      ~vcandidates.ckdir
      ~vcandidates.ckpython
      ~vcandidates.closefig
      ~vcandidates.common_ele
      ~vcandidates.compute_contours
      ~vcandidates.flatten
      ~vcandidates.gcn_server
      ~vcandidates.getkeys
      ~vcandidates.healpyshow
      ~vcandidates.ipix_in_box
      ~vcandidates.is_seq
      ~vcandidates.is_seq_of_seq
      ~vcandidates.locshow
      ~vcandidates.notes
      ~vcandidates.plot_coord
      ~vcandidates.plot_lines
      ~vcandidates.plot_points
      ~vcandidates.plot_sky
      ~vcandidates.projplot
      ~vcandidates.readlist
      ~vcandidates.savefig
      ~vcandidates.setkeys
      ~vcandidates.vertices
      ~vcandidates.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~vcandidates.defkwargs
      ~vcandidates.exkwargs
      ~vcandidates.version
   
   