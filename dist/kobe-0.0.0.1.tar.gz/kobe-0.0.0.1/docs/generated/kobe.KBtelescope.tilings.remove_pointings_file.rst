kobe.KBtelescope.tilings.remove\_pointings\_file
================================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.remove_pointings_file