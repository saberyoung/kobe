kobe.KBobservatory.observatory.parse\_location
==============================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.parse_location