kobe.KBtelescope.telescope.decide\_strategy
===========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: telescope.decide_strategy