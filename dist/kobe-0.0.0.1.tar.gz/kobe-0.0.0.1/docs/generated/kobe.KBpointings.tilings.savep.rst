kobe.KBpointings.tilings.savep
==============================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.savep