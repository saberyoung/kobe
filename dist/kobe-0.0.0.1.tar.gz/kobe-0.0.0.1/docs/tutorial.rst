KOBE tutorial
===================================

Documentation for KOBE is hosted by `Read the Docs <http://kobe.readthedocs.org/en/stable/>`_.

:ref:`1. Scheme and General settings  <kbscheme>`
--------------------------------------------------

:ref:`2. Pointing <kbpoint>`
----------------------------------------------

:ref:`3. Telescope and Observatory <kbtel>`
-------------------------------------------------

:ref:`4. Candidates <kbcand>`
-------------------------------------------------

:ref:`5. Triggers <kbtrigger>`
----------------------------------------

:ref:`6. Priorization and Optimization <kbprio>`
-------------------------------------------------
