.. kobe.KBschedule:

.. currentmodule:: kobe.KBschedule


:mod:`schedule` -- makeing telescope schedule
==========================================================================

Schedule
--------------------
.. autosummary::
   :toctree: generated/

   schedule
   schedule.add_observatory
   schedule.del_observatory
   schedule.prioritization
