.. kobe.KBtriggers:

.. currentmodule:: kobe.KBtrigger


:mod:`triggers` -- dealing with trigger map
==================================================================

KBtrigger
--------------------
.. autosummary::
   :toctree: generated/

   trigger
   trigger.parse_trigger
   trigger.url
   trigger.fits
   trigger.xml
   trigger.root
   trigger.coo
   trigger.trigger_report
   trigger.calc_loc_contours
   trigger.calc_loc_area
   trigger.locshow
