kobe.KBtrigger.trigger.url
==========================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.url