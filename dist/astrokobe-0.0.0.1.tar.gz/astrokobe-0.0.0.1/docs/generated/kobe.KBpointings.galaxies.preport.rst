kobe.KBpointings.galaxies.preport
=================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.preport