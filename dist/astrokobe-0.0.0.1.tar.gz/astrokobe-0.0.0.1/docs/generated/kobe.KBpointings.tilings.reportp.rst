kobe.KBpointings.tilings.reportp
================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.reportp