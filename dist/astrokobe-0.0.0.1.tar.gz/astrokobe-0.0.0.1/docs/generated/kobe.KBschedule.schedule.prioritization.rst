kobe.KBschedule.schedule.prioritization
=======================================

.. currentmodule:: kobe.KBschedule

.. automethod:: schedule.prioritization