kobe.KBtrigger.trigger.triggershow
==================================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.triggershow