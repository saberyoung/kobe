kobe.KBtelescope.galaxies.galaxies2hpmap
========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.galaxies2hpmap