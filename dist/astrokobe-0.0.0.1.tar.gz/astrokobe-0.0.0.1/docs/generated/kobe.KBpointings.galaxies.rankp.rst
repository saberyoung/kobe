kobe.KBpointings.galaxies.rankp
===============================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.rankp