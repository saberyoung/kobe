kobe.KBtelescope.galaxies.generate\_pointings
=============================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.generate_pointings