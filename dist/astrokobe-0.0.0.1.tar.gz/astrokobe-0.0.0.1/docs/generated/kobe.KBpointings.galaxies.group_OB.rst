kobe.KBpointings.galaxies.group\_OB
===================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.group_OB