kobe.KBtelescope.galaxies.remove\_pointings\_file
=================================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.remove_pointings_file