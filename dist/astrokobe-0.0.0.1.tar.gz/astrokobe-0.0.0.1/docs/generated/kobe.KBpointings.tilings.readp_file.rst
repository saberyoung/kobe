kobe.KBpointings.tilings.readp\_file
====================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.readp_file