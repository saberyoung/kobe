kobe.KBpointings.tilings.rankp
==============================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.rankp