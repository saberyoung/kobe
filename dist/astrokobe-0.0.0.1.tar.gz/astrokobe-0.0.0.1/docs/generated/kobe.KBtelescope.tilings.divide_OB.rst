kobe.KBtelescope.tilings.divide\_OB
===================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.divide_OB