kobe.KBschedule.schedule.del\_observatory
=========================================

.. currentmodule:: kobe.KBschedule

.. automethod:: schedule.del_observatory