kobe.KBpointings.tilings.removep\_coo
=====================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.removep_coo