kobe.KBpointings.galaxies.readp\_file
=====================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.readp_file