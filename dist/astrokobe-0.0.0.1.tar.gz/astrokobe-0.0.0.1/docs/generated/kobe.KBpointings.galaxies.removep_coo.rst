kobe.KBpointings.galaxies.removep\_coo
======================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.removep_coo