kobe.KBtrigger.trigger.coo
==========================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.coo