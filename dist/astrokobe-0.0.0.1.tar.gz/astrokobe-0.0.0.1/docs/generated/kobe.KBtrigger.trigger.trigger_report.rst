kobe.KBtrigger.trigger.trigger\_report
======================================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.trigger_report