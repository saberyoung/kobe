kobe.KBtrigger.trigger.calc\_loc\_contours
==========================================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.calc_loc_contours