kobe.KBpointings.tilings.preport
================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.preport