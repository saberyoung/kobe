kobe.KBtrigger.trigger.xml
==========================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.xml