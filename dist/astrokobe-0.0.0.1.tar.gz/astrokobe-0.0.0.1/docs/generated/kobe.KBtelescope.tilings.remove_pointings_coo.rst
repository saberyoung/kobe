kobe.KBtelescope.tilings.remove\_pointings\_coo
===============================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.remove_pointings_coo