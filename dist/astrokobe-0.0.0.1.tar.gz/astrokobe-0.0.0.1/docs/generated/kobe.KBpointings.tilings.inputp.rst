kobe.KBpointings.tilings.inputp
===============================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.inputp