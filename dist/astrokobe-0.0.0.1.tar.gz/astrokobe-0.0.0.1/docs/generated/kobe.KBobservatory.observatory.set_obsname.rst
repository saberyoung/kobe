kobe.KBobservatory.observatory.set\_obsname
===========================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.set_obsname