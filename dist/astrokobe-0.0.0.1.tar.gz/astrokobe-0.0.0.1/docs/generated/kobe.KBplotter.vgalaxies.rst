kobe.KBplotter.vgalaxies
========================

.. currentmodule:: kobe.KBplotter

.. autoclass:: vgalaxies

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~vgalaxies.__init__
      ~vgalaxies.ckdir
      ~vgalaxies.ckpython
      ~vgalaxies.closefig
      ~vgalaxies.common_ele
      ~vgalaxies.compute_contours
      ~vgalaxies.flatten
      ~vgalaxies.gcn_server
      ~vgalaxies.getkeys
      ~vgalaxies.healpyshow
      ~vgalaxies.ipix_in_box
      ~vgalaxies.is_seq
      ~vgalaxies.is_seq_of_seq
      ~vgalaxies.locshow
      ~vgalaxies.notes
      ~vgalaxies.plot_coord
      ~vgalaxies.plot_lines
      ~vgalaxies.plot_points
      ~vgalaxies.plot_sky
      ~vgalaxies.projplot
      ~vgalaxies.readlist
      ~vgalaxies.savefig
      ~vgalaxies.setkeys
      ~vgalaxies.vertices
      ~vgalaxies.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~vgalaxies.defkwargs
      ~vgalaxies.exkwargs
      ~vgalaxies.version
   
   