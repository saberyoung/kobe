kobe.KBobservatory.observatory.frame
====================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.frame