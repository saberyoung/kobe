kobe.KBtelescope.telescope.set\_telname
=======================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: telescope.set_telname