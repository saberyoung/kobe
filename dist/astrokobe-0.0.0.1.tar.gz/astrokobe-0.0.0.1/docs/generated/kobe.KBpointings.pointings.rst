kobe.KBpointings.pointings
==========================

.. currentmodule:: kobe.KBpointings

.. autoclass:: pointings

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~pointings.__init__
   
   

   
   
   