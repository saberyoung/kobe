kobe.KBpointings.tilings.readp
==============================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.readp