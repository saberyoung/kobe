kobe.KBpointings.tilings.group\_OB
==================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.group_OB