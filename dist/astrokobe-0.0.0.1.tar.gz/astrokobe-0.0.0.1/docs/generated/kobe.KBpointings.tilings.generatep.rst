kobe.KBpointings.tilings.generatep
==================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.generatep