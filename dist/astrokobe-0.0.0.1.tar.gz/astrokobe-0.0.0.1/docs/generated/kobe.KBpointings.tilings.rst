kobe.KBpointings.tilings
========================

.. currentmodule:: kobe.KBpointings

.. autoclass:: tilings

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~tilings.__init__
      ~tilings.ckdir
      ~tilings.ckpython
      ~tilings.closefig
      ~tilings.common_ele
      ~tilings.compute_contours
      ~tilings.divide_OB
      ~tilings.divide_OB_one
      ~tilings.flatten
      ~tilings.gcn_server
      ~tilings.generatep
      ~tilings.getkeys
      ~tilings.healpyshow
      ~tilings.ipix_in_box
      ~tilings.is_seq
      ~tilings.is_seq_of_seq
      ~tilings.locshow
      ~tilings.notes
      ~tilings.plot_coord
      ~tilings.plot_lines
      ~tilings.plot_points
      ~tilings.plot_sky
      ~tilings.projplot
      ~tilings.read_slackid
      ~tilings.readlist
      ~tilings.readp
      ~tilings.removep_coo
      ~tilings.removep_file
      ~tilings.savefig
      ~tilings.savep
      ~tilings.send_email
      ~tilings.send_slack
      ~tilings.send_sms
      ~tilings.setkeys
      ~tilings.vertices
      ~tilings.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~tilings.attachments
      ~tilings.data
      ~tilings.defkwargs
      ~tilings.exkwargs
      ~tilings.images
      ~tilings.texts
      ~tilings.version
   
   