kobe.KBobservatory.observatory.parse\_time
==========================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.parse_time