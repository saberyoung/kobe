kobe.KBpointings.galaxies.generatep
===================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.generatep