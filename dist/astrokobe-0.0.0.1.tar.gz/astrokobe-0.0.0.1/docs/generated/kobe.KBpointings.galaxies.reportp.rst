kobe.KBpointings.galaxies.reportp
=================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.reportp