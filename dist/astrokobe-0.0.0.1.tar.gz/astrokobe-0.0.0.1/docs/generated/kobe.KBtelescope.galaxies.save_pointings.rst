kobe.KBtelescope.galaxies.save\_pointings
=========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.save_pointings