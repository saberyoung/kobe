kobe.KBtelescope.galaxies.read\_pointings
=========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.read_pointings