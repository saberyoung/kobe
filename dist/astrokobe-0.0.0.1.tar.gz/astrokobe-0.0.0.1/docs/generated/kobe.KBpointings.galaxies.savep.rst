kobe.KBpointings.galaxies.savep
===============================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.savep