kobe.KBobservatory.observatory.calc\_moon\_illumination
=======================================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.calc_moon_illumination