kobe.KBtelescope.telescope.set\_pointings
=========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: telescope.set_pointings