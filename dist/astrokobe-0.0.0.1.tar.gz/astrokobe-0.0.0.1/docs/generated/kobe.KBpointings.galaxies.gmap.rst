kobe.KBpointings.galaxies.gmap
==============================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.gmap