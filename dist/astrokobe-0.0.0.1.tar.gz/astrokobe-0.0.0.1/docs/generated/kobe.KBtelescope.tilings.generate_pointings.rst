kobe.KBtelescope.tilings.generate\_pointings
============================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.generate_pointings