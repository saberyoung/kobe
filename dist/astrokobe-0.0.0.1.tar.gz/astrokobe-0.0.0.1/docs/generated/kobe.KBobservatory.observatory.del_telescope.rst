kobe.KBobservatory.observatory.del\_telescope
=============================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.del_telescope