kobe.KBpointings.tilings.dividep
================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.dividep