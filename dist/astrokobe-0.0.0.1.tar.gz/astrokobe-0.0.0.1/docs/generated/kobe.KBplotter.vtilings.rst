kobe.KBplotter.vtilings
=======================

.. currentmodule:: kobe.KBplotter

.. autoclass:: vtilings

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~vtilings.__init__
      ~vtilings.ckdir
      ~vtilings.ckpython
      ~vtilings.closefig
      ~vtilings.common_ele
      ~vtilings.compute_contours
      ~vtilings.flatten
      ~vtilings.gcn_server
      ~vtilings.getkeys
      ~vtilings.healpyshow
      ~vtilings.ipix_in_box
      ~vtilings.is_seq
      ~vtilings.is_seq_of_seq
      ~vtilings.locshow
      ~vtilings.notes
      ~vtilings.plot_coord
      ~vtilings.plot_lines
      ~vtilings.plot_points
      ~vtilings.plot_sky
      ~vtilings.projplot
      ~vtilings.readlist
      ~vtilings.savefig
      ~vtilings.setkeys
      ~vtilings.vertices
      ~vtilings.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~vtilings.defkwargs
      ~vtilings.exkwargs
      ~vtilings.version
   
   