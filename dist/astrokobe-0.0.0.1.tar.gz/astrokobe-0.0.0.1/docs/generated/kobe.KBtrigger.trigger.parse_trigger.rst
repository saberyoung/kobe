kobe.KBtrigger.trigger.parse\_trigger
=====================================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.parse_trigger