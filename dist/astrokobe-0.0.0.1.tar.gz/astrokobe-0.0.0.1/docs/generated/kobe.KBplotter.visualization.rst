kobe.KBplotter.visualization
============================

.. currentmodule:: kobe.KBplotter

.. autoclass:: visualization

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~visualization.__init__
      ~visualization.ckdir
      ~visualization.ckpython
      ~visualization.closefig
      ~visualization.common_ele
      ~visualization.compute_contours
      ~visualization.flatten
      ~visualization.gcn_server
      ~visualization.getkeys
      ~visualization.healpyshow
      ~visualization.ipix_in_box
      ~visualization.is_seq
      ~visualization.is_seq_of_seq
      ~visualization.notes
      ~visualization.plot_coord
      ~visualization.plot_lines
      ~visualization.plot_points
      ~visualization.plot_sky
      ~visualization.projplot
      ~visualization.readlist
      ~visualization.savefig
      ~visualization.setkeys
      ~visualization.vertices
      ~visualization.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~visualization.defkwargs
      ~visualization.exkwargs
      ~visualization.version
   
   