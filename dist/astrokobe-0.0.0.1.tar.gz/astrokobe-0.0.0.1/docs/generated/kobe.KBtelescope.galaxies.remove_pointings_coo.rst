kobe.KBtelescope.galaxies.remove\_pointings\_coo
================================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: galaxies.remove_pointings_coo