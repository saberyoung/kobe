kobe.KBpointings.tilings.readp\_coo
===================================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.readp_coo