kobe.KBtelescope.tilings.save\_pointings
========================================

.. currentmodule:: kobe.KBtelescope

.. automethod:: tilings.save_pointings