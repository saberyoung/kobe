kobe.KBobservatory.observatory.EarthLocation\_from\_kobe
========================================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.EarthLocation_from_kobe