kobe.KBobservatory.observatory.calc\_sun\_height
================================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.calc_sun_height