kobe.KBplotter.vtrigger
=======================

.. currentmodule:: kobe.KBplotter

.. autoclass:: vtrigger

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~vtrigger.__init__
      ~vtrigger.ckdir
      ~vtrigger.ckpython
      ~vtrigger.closefig
      ~vtrigger.common_ele
      ~vtrigger.compute_contours
      ~vtrigger.cumshow
      ~vtrigger.distview
      ~vtrigger.flatten
      ~vtrigger.galaxyshow_all
      ~vtrigger.galaxyshow_obs
      ~vtrigger.galaxyshow_tel
      ~vtrigger.gcn_server
      ~vtrigger.getkeys
      ~vtrigger.healpyshow
      ~vtrigger.ipix_in_box
      ~vtrigger.is_seq
      ~vtrigger.is_seq_of_seq
      ~vtrigger.locshow
      ~vtrigger.lumsview
      ~vtrigger.notes
      ~vtrigger.plot_coord
      ~vtrigger.plot_lines
      ~vtrigger.plot_points
      ~vtrigger.plot_sky
      ~vtrigger.projplot
      ~vtrigger.readlist
      ~vtrigger.routeview
      ~vtrigger.savefig
      ~vtrigger.setkeys
      ~vtrigger.tilingshow_all
      ~vtrigger.tilingshow_obs
      ~vtrigger.tilingshow_tel
      ~vtrigger.vertices
      ~vtrigger.writelist
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~vtrigger.defkwargs
      ~vtrigger.exkwargs
      ~vtrigger.version
   
   