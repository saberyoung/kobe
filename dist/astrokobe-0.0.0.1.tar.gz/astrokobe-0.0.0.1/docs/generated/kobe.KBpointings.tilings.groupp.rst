kobe.KBpointings.tilings.groupp
===============================

.. currentmodule:: kobe.KBpointings

.. automethod:: tilings.groupp