kobe.KBtrigger.trigger.locshow
==============================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.locshow