kobe.KBpointings.galaxies.groupp
================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.groupp