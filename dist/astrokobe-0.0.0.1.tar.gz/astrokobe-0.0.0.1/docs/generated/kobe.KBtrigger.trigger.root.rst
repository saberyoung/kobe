kobe.KBtrigger.trigger.root
===========================

.. currentmodule:: kobe.KBtrigger

.. automethod:: trigger.root