kobe.KBobservatory.observatory.add\_telescope
=============================================

.. currentmodule:: kobe.KBobservatory

.. automethod:: observatory.add_telescope