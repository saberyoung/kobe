kobe.KBpointings.galaxies.galaxies2hpmap
========================================

.. currentmodule:: kobe.KBpointings

.. automethod:: galaxies.galaxies2hpmap