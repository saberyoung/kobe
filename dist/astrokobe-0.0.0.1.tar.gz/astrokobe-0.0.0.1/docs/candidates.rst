.. kobe.KBcandidates:

.. currentmodule:: kobe.KBcandidates


:mod:`candidates` -- define a list of candidates and targeting lightcurves
==============================================================================

pointing
--------------------
.. autosummary::
   :toctree: generated/

   candidates
